<?php

include('utils.php'); 

function searchHighResolutionPic($photo_reference, $max_width, $api_key)
{
	$url = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=" . $max_width . "&photoreference=" . $photo_reference . "&key=" . $api_key;
	$responsetext = file_get_contents($url);
	$path = $photo_reference . ".jpg";
	file_put_contents($path, $responsetext);
	return $path;
}

function searchPlaceDetails($place_id, $api_key)
{
	$url = "https://maps.googleapis.com/maps/api/place/details/json?placeid=" . $place_id . "&key=" . $api_key;
	$json_responsetext = Utils::requestGoogleAPI($url);
	$requested_result = array();
	$requested_result['result']['reviews'] = array();
	$requested_result['result']['photos'] = array();

	$max_num = 5;
	$count = 1;
	foreach ($json_responsetext['result']['reviews'] as $review) 
	{

		$single_result = array();
		$single_result['author_name'] = $review['author_name'];
		$single_result['profile_photo_url'] = $review['profile_photo_url'];
		$single_result['text'] = $review['text'];
		
		array_push($requested_result['result']['reviews'], $single_result);

		if ($count >= $max_num) {
			break;
		}
		else
		{
			$count = $count + 1;
		}
	}

	$count = 1;
	foreach ($json_responsetext['result']['photos'] as $photo) 
	{
		$path = searchHighResolutionPic($photo['photo_reference'], 600, $api_key);
		array_push($requested_result['result']['photos'], $path);

		if ($count >= $max_num) {
			break;
		}
		else
		{
			$count = $count + 1;
		}
	}

	$requested_result['result']['name'] = $json_responsetext['result']['name'];

	$requested_result['status'] = $json_responsetext['status'];

	return json_encode($requested_result);
	//return json_encode($json_responsetext);
}

$api_key = parse_ini_file('../properties/global.ini')['api_key'];
$place_id = $_POST["place_id"];
echo searchPlaceDetails($place_id, $api_key);

// echo 1;
?>